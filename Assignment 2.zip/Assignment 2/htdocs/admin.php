<?php
// Database connection
$user = 'root';
$pass = '';
$dbName = 'Hospital';

$conn = new mysqli('localhost', $user, $pass, $dbName);

// Check connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Handle login
$error_message = '';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = isset($_POST['Admin_username']) ? $_POST['Admin_username'] : '';
    $password = isset($_POST['Admin_password']) ? $_POST['Admin_password'] : '';

    if ($username && $password) {
        // Prepare and execute SQL query
        $username = $conn->real_escape_string($username);
        $password = $conn->real_escape_string($password);
        $sql = "SELECT * FROM admin WHERE username = '$username' AND password = '$password'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Successful login
            session_start();
            $_SESSION['admin_username'] = $username;
            header('Location: admin_dashboard.php');
            exit();
        } else {
            // Invalid credentials
            $error_message = 'Invalid username or password. Please try again.';
        }
    } else {
        $error_message = 'Please enter both username and password.';
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Login</title>
    <style>
        /* General body styles */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f2f5;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        /* Login container styles */
        .login-container {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            width: 300px;
            text-align: center;
        }

        .login-container .icon {
            font-size: 50px;
            color: #007bff;
            margin-bottom: 10px;
        }

        .login-container p {
            font-size: 18px;
            color: #333;
            margin: 0 0 20px;
        }

        .login-container form {
            display: flex;
            flex-direction: column;
        }

        .login-container input[type="text"],
        .login-container input[type="password"] {
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .login-container input[type="submit"] {
            background-color: #007bff;
            color: #ffffff;
            border: none;
            padding: 10px;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        .login-container input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .error-message {
            color: #dc3545;
            margin-top: 10px;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <span class="icon">🛡️</span>
        <p>Login as Admin</p>
        <form action="AdminLogin.php" method="POST" enctype="application/x-www-form-urlencoded" onsubmit="handleLogin(event)">
            <div>
                <input type="text" name="Admin_username" placeholder="Username" required>
            </div>
            <div>
                <input type="password" name="Admin_password" placeholder="Password" required>
            </div>
            <div>
                <input type="submit" value="Login">
            </div>
        </form>
        <?php if ($error_message): ?>
            <div id="error-message" class="error-message"><?php echo htmlspecialchars($error_message); ?></div>
        <?php endif; ?>
    </div>

    <script>
        let attemptCount = 0;
        function handleLogin(event) {
            attemptCount++;
            if (attemptCount >= 3) {
                document.getElementById('error-message').style.display = 'block';
                document.getElementById('error-message').textContent = 'Too many failed attempts. Please try again later.';
                // Disable form submission after too many attempts
                event.preventDefault();
                // Optionally disable the submit button to prevent further attempts
                document.querySelector('input[type="submit"]').disabled = true;
            }
        }
    </script>
</body>
</html>
