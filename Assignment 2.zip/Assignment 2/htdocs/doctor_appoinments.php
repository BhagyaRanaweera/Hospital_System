<?php
$appointments = []; // Initialize an array to hold all appointment data

// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Hospital";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} else {
   
}

// Fetch all appointment records from the database
$sql = "SELECT * FROM appointment";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Store all fetched data in the $appointments array
    while ($row = $result->fetch_assoc()) {
        $appointments[] = $row;
    }
} else {
    echo "No appointments found.<br>";
}

// Close the connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Details</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <img src="images/Hospital.png" alt="Hospital Logo">
                <h1>Kings Hospital &rarr;</h1>
                <h4>Admin panel</h4>
            </div>
            <div class="logout">
                <form action="doctor_login.php" method="POST">
                    <button type="submit" id="logoutButton" style="color: aliceblue;">Logout</button>
                </form>
            </div>
        </header>
        
                <h2>Appointment Details</h2>
                <?php if (!empty($appointments)): ?>
                    <table>
                        <thead>
                            <tr>
                               
                                <th>Patient Name</th>
                                <th>Date</th>
                                <th>Time</th>
                                <th>Fee</th>
                                <th>Doctor Name</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($appointments as $appointment): ?>
                            <tr>
                              
                                <td><?php echo htmlspecialchars($appointment['patient_name']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['date']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['time']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['fee']); ?></td>
                                <td><?php echo htmlspecialchars($appointment['doctor_name']); ?></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <p>No appointments found.</p>
                <?php endif; ?>
            </main>
        </div>
    </div>
    <script>
        document.addEventListener('DOMContentLoaded', () => {
            // Add confirmation dialog for logout button
            const logoutButton = document.getElementById('logoutButton');
            if (logoutButton) {
                logoutButton.addEventListener('click', (event) => {
                    if (!confirm('Are you sure you want to logout?')) {
                        event.preventDefault();
                    }
                });
            }

            // Add hover effect to table rows for better UX
            const tableRows = document.querySelectorAll('table tbody tr');
            tableRows.forEach(row => {
                row.addEventListener('mouseover', () => {
                    row.style.backgroundColor = '#f0f0f0'; // Light grey background on hover
                });
                row.addEventListener('mouseout', () => {
                    row.style.backgroundColor = ''; // Remove background color on mouse out
                });
            });
        });
    </script>
</body>
</html>
