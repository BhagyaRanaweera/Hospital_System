<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$email = $_POST['email'];
$password = $_POST['password'];

// Prepare and bind the SQL statement
$stmt = $conn->prepare("SELECT password FROM patient_data WHERE email = ?");
$stmt->bind_param("s", $email);

// Execute the query
$stmt->execute();
$stmt->bind_result($stored_password);
$stmt->fetch();

// Check if the email exists in the database and if the password matches
if ($stored_password && $stored_password == $password) {
    echo "<script>
        alert('Logging in successfully..!');
        window.location.href='Patient Dashboard.php?value=" . urlencode($email) . "';
    </script>";
} else {
    echo "<script>
        alert('Incorrect email or password..!');
        window.location.href='patient.php';
    </script>";
}

// Close the statement and connection
$stmt->close();
$conn->close();
?>
