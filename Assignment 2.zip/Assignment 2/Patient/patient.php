

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Login</title>
    <link rel="stylesheet" href="stylesheet.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #e0f7fa;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .login-container {
            display: block;
            background-color: #fff;
            padding: 2em;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .login-container p {
            font-size: 1.5em;
            margin-bottom: 1em;
            color: #333;
        }
        .login-container input[type="text"],
        .login-container input[type="email"],
        .login-container input[type="number"],
        .login-container input[type="password"] {
            width: 80%;
            padding: 0.5em;
            margin: 0.5em 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        .login-container input[type="submit"] {
            background-color: #00796b;
            color: white;
            padding: 0.75em 1.5em;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .login-container input[type="submit"]:hover {
            background-color: #00495c;
        }
        .login-container .register-link {
            margin-top: 1em;
            display: block;
            color: #00796b;
            text-decoration: none;
        }
        .login-container .register-link:hover {
            text-decoration: underline;
        }
        .icon {
            font-size: 4em;
            color: #00796b;
        }

        .registeration{
            display: none;
            font-size: 18px;
            color: #333;
            background-color: #fff;
            padding: 2em;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: left;
        }
        .registeration input[type="submit"] {
            background-color: #00796b;
            color: white;
            padding: 0.75em 1.5em;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .registeration input[type="submit"]:hover {
            background-color: #00495c;
        }
        .link {
            margin-top: 1em;
            display: block;
            color: #00796b;
            text-decoration: none;
        }
        .link:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div id="log" class="login-container">
        <span class="icon">🤒</span>
        <p>Login as Patient</p>
        <form action="check_user.php" method="post">
            <div>
                <input type="email" name="email" placeholder="Enter your email" required>
            </div>
            <div>
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <div>
            <input type="submit" value="Login">
            </div>
        </form>
        
        <a class="register-link" onclick="showRegister()">Not registered? Click here to sign up.</a>
    </div>
<br>
    <div id="register" class="registeration">
        <b><u><h2>Register as patient</h2></u></b>
        <br>
        <form action="store_data.php" method="post">
            Name : <input id="name" type="text" name="name" placeholder="Enter name" required>
            <br><br>
            Email : <input id="email" type="email" name="email" placeholder="Enter email" required>
            <br><br>
            NIC : <input id="nic" type="text" name="nic" placeholder="Enter NIC" required>
            <br><br>
            Gender : <input id="gender" type="radio" name="gender" value="male" required>Male <input type="radio" name="gender" value="female">Female
            <br><br>
            Age : <input id="age" type="number" name="age" placeholder="Enter age" required>
            <br><br>
            Password : <input id="age" type="text" name="password" placeholder="Enter password" required>
            <br><br>
            Confirm Password : <input id="age" type="text" placeholder="Confirm password">
            <br><br>
            <input type="submit" value="Register">
        </form>
        <a class="link" onclick="showLog()">Alredy have a account? Click here to sign In.</a>
    </div>

    <script>
        function showRegister(){
            document.getElementById('register').style.display = 'block';
            document.getElementById('log').style.display = 'none';
        }
        function showLog(){
            document.getElementById('register').style.display = 'none';
            document.getElementById('log').style.display = 'block';
        }

        function clickRegisterButton() {
    // Get form data
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const gender = document.getElementById('gender').value;
    const nic = document.getElementById('nic').value;
    const age = document.getElementById('age').value;
    alert(name+email+gender+nic+age);
    
}
    </script>
</body>
</html>


