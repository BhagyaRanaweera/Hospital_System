function validateForm(){
    if(document.forms["from1"]["fullName"].value == ""){
        alert("Name must be filled.");
        return false;
    }
    else if(document.forms["from1"]["email"].value == ""){
        alert("Email must be filled.");
        return false;
    }
    else if(document.forms["from1"]["email"].value != ""){
        if(/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(from1.email.value)){
            return (true);
        }
        alert("Enter valid email!!!");
        return (false);
    }
    else if(document.forms["from1"]["phoneNumber"].value == ""){
        alert("Phone number must be filled.");
        return false;
    }
    else if(document.forms["from1"]["subject"].value == ""){
        alert("Subject must be filled.");
        return false;
    }
    else if(document.forms["from1"]["message"].value == ""){
        alert("Message must be filled.");
        return false;
    }
}