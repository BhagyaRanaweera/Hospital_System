<?php
// store_data.php

// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Database configuration
    $servername = "localhost"; // or your server name
    $username = "root"; // your database username
    $password = ""; // your database password
    $dbname = "Hospital"; // your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Get form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $gender =$_POST['gender'];
    $nic = $_POST['nic'];
    $age = $_POST['age'];
    $password = $_POST['password'];

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO patient_data (name, email, gender, nic, age,password) VALUES (?, ?, ?, ?, ?,?)");
    $stmt->bind_param("ssssis", $name, $email,$nic,$gender,$age,$password);

    // Execute the query
    if ($stmt->execute()) {
        echo "<script>
        alert('Registeration successfully ..!');
        window.location.href='patient.php';

        </script>";
        
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}

?>