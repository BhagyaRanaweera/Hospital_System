<?php
$host = 'localhost';
$db = 'hospital';
$user = 'root';
$pass = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

// Initialize search query
$search = '';
$query = 'SELECT name, email, nic, age, gender, password FROM patient_data';
$params = [];

// Check if a search term is provided
if (isset($_POST['search']) && !empty($_POST['search'])) {
    $search = $_POST['search'];
    $query .= ' WHERE nic LIKE :search';
    $params[':search'] = "%$search%";
}

// Prepare and execute query
$stmt = $pdo->prepare($query);
$stmt->execute($params);
$patients = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient List</title>
    <link rel="stylesheet" href="Styles.css">
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Highlight the active sidebar link
            const sidebarLinks = document.querySelectorAll('.sidebar ul li a');
            sidebarLinks.forEach(link => {
                link.addEventListener('click', function() {
                    sidebarLinks.forEach(l => l.classList.remove('active'));
                    this.classList.add('active');
                });
            });

            // Confirmation before logging out
            const logoutButton = document.getElementById('logoutButton');
            logoutButton.addEventListener('click', function(event) {
                const confirmLogout = confirm('Are you sure you want to log out?');
                if (!confirmLogout) {
                    event.preventDefault();
                }
            });

            // Focus on the search input field when the page loads
            const searchInput = document.querySelector('input[name="search"]');
            if (searchInput) {
                searchInput.focus();
            }
        });
    </script>
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <img src="images/Hospital.png" alt="Hospital Logo">
                <h1>Kings Hospital &rarr;</h1><h4> Admin panel</h4>
            </div>
            <div class="logout">
                <form action="admin.php" method="POST">
                    <button type="submit" id="logoutButton" style="color: aliceblue;">Logout</button>
                </form>
            </div>
        </header>
        <div class="content">
            <aside class="sidebar">
                <ul>
                    <li><a href="AdminLogin.php" id="dashboardLink">Dashboard</a></li>
                    <li><a href="doctor_list.php" id="doctorListLink">Doctor List</a></li>
                    <li><a href="patient_list.php" id="patientListLink">Patient List</a></li>
                    <li><a href="appoinment_details.php" id="appointmentDetailsLink">Appointment Details</a></li>
                    <li><a href="add_doctor.php" id="addDoctorLink">Add Doctor</a></li>
                    <li><a href="message.php" id="messagesLink">Messages</a></li>
                </ul>
            </aside>
            <main>
                <h2>Patient List</h2>
                <form method="POST">
                    <input type="text" name="search" placeholder="Search by NIC" value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit">Search</button>
                </form>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Email</th>
                            <th>NIC</th>
                            <th>Age</th>
                            <th>Gender</th>
                            <th>Password</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($patients as $patient): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($patient['name']); ?></td>
                            <td><?php echo htmlspecialchars($patient['email']); ?></td>
                            <td><?php echo htmlspecialchars($patient['nic']); ?></td>
                            <td><?php echo htmlspecialchars($patient['age']); ?></td>
                            <td><?php echo htmlspecialchars($patient['gender']); ?></td>
                            <td><?php echo htmlspecialchars($patient['password']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </main>
        </div>
    </div>
</body>
</html>
