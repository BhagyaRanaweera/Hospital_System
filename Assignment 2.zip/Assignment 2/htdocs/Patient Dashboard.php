<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Hospital";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user email from check_user.php
session_start();
if (isset($_GET['value'])) {
    $email = $_GET['value'];
} else {
    echo "No User email came from check_user..!";
    exit;
}

// SQL query to fetch patient data
$stmt = $conn->prepare("SELECT * FROM patient_data WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user) {
    $name = $user['name'];
    $age = $user['age'];
    $gender = $user['gender'];
    $nic = $user['nic'];
} else {
    echo "No patient data found for the given email.";
    exit;
}

// SQL query to fetch appointment history
$aph = "SELECT * FROM appointment WHERE patient_name = ?";
$d = $conn->prepare($aph);
$d->bind_param("s", $name);
$d->execute();
$appointment = $d->get_result();

$objects_array = [];
while ($row = $appointment->fetch_object()) {
    $objects_array[] = $row;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Patient Dashboard</title>
    <link rel="stylesheet" href="stylesheet.css">
</head>
<body>

    <div class="top-area">
        <table>
            <tr>
                <th><img src="Images/Hospital.png" class="responsive-image" alt="Hospital Logo"></th>
                <th><h2>Kings Hospital </h2></th>
                <th><img src="Images/nextIcon.png" class="nextIcon-top" alt="Next Icon"></th>
                <th><h4>Patient Panel</h4></th>
            </tr>
        </table>
    </div>

    <div class="grid-container">
        <div class="grid-item1">
            <ul class="list">
                <li class="centered">
                    <div class="circle">
                        <img src="Images/Patient Icon.png" class="responsive-image" alt="Patient Icon">
                    </div>
                </li>
                <li><button class="button" onclick="showContainer('container1', this)">Dashboard</button></li>
                <li><button class="button" onclick="showContainer('container2', this)">My Profile</button></li>
                <li><button class="button" onclick="showContainer('container3', this)">Book Appointment</button></li>
                <li><button class="button" onclick="showContainer('container4', this)">Appointment History</button></li>
                <li><a href="patient.php"><button class="button">Logout</button></a></li>
            </ul>
        </div>

        <div class="grid-item2">
            <!-- Dashboard -->
            <div id="container1" class="container active">
                <h2>Welcome <?php echo htmlspecialchars($name); ?>!</h2>
                <div class="box">
                    <table class="table">
                        <tr>
                            <th>
                                <a onclick="showContainer('container3', this)">
                                    <div class="box-add"><img src="Images/Book a appoientment.png" class="responsive-image" alt="Book Appointment Icon"></div>
                                </a>
                            </th>
                            <th>
                                <a onclick="showContainer('container4', this)">
                                    <div class="box-add"><img src="Images/Appointment history.png" class="responsive-image" alt="Appointment History Icon"></div>
                                </a>
                            </th>
                        </tr>
                        <tr>
                            <td>My Appointment</td>
                            <td>Book A New Appointment</td>
                        </tr>
                        <tr>
                            <td><div class="font">My Appointment</div></td>
                            <td><div class="font">Appointment History</div></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- My Profile -->
            <div id="container2" class="container">
                <h2>Your Profile</h2>
                <div class="box">
                    <h3><u>Personal Details</u></h3>
                    <table class="table1">
                        <tr>
                            <td>Name</td>
                            <td>: <?php echo htmlspecialchars($name); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td>: <?php echo htmlspecialchars($email); ?></td>
                        </tr>
                        <tr>
                            <td>NIC</td>
                            <td>: <?php echo htmlspecialchars($nic); ?></td>
                        </tr>
                        <tr>
                            <td>Age</td>
                            <td>: <?php echo htmlspecialchars($age); ?></td>
                        </tr>
                        <tr>
                            <td>Gender</td>
                            <td>: <?php echo htmlspecialchars($gender); ?></td>
                        </tr>
                    </table>
                </div>
            </div>

            <!-- Book Appointment -->
            <div id="container3" class="container">
                <h2>Book an Appointment</h2>
                <div class="box">
                    <form action="book_appointment.php" method="post">
                        <table class="table1">
                            <tr>
                                <td><label for="name">Patient</label></td>
                                <td><input name="name" value="<?php echo htmlspecialchars($name); ?>" readonly></td>
                            </tr>
                            <tr>
                                <td><label for="doctors">Doctors</label></td>
                                <td>
                                    <select id="doctors" name="doctor" required>
                                        <option value="">Choose a Doctor</option>
                                        <option value="doctor1">Doctor 1</option>
                                        <option value="doctor2">Doctor 2</option>
                                        <option value="doctor3">Doctor 3</option>
                                        <option value="doctor4">Doctor 4</option>
                                        <option value="doctor5">Doctor 5</option>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <td><label for="date">Date</label></td>
                                <td><input type="date" id="date" name="date" required></td>
                            </tr>
                            <tr>
                                <td><label for="time">Time</label></td>
                                <td><input type="time" id="time" name="time" required></td>
                            </tr>
                            <tr>
                                <td><label for="fee">Consultancy Fee</label></td>
                                <td><label for="fee">2000/=</label></td>
                            </tr>
                        </table>
                        <button class="submit-button" type="submit">Create New Entry</button>
                    </form>
                </div>
            </div>

            <!-- Appointment History -->
            <div id="container4" class="container">
                <h2>Your Appointment History</h2>
                <div class="box">
                    <table class="appointment-history">
                        <tr>
                            <td><b>Doctor Name</b></td>
                            <td><b>Consultancy Fee</b></td>
                            <td><b>Appointment Date</b></td>
                            <td><b>Appointment Time</b></td>
                        </tr>
                    </table>
                    <hr>
                    <table class="appointment-history">
                        <?php
                        foreach ($objects_array as $object) {
                            echo "<tr>";
                            echo "<td>" . htmlspecialchars($object->doctor_name) . "</td>";
                            echo "<td>" . htmlspecialchars($object->fee) . "/=</td>";
                            echo "<td>" . htmlspecialchars($object->date) . "</td>";
                            echo "<td>" . htmlspecialchars($object->time) . "</td>";
                            echo "</tr>";
                        }
                        ?>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showContainer(containerId, button) {
            var containers = document.querySelectorAll('.container');
            containers.forEach(function(container) {
                container.classList.remove('active');
            });
            var activeContainer = document.getElementById(containerId);
            activeContainer.classList.add('active');
            var buttons = document.querySelectorAll('.button');
            buttons.forEach(function(btn) {
                if (btn !== button) {
                    btn.classList.remove('clicked');
                }
            });
            button.classList.toggle('clicked');
        }
        document.addEventListener("DOMContentLoaded", function() {
            document.querySelector('.button').classList.add('clicked');
        });
    </script>

</body>
</html>
