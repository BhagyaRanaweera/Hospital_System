<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "hospital";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//get useremail from check_user.php
session_start();
if (isset($_GET['value'])) {
    $email = $_GET['value'];
} else {
    echo "No User email came from cheack user..!";
}

// SQL query to fetch data
$stmt = $conn->prepare("SELECT * FROM patient_data WHERE email = ?");
$stmt->bind_param("s", $email);
// Execute the query
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$name=$user['name'];
$email=$user['email'];
$age=$user['age'];
$gender=$user['gender'];
$nic=$user['nic'];

"SELECT * FROM appointment WHERE patient_name = ?";
// get appointment history
$aph ="SELECT * FROM appointment WHERE patient_name = ?";
$d = $conn->prepare($aph);
$d->bind_param("s", $name);
$d->execute();

// Get the result
$appointment = $d->get_result();

$objects_array = [];
while ($row = $appointment->fetch_object()) {
    $objects_array[] = $row;
}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=0.0">
    <title>Patient DashBoard</title>
    <link rel="stylesheet" href="stylesheet.css">
</head>
<body>

    <div class="top-area">
        <table>
            <tr>
                <th><img src="Images\Hospital.png"
                    class="responsive-image"
                     alt="Description of image"></th>
                <th><h2>Kings Hospital </h2></th>
                <th><img src="Images\nextIcon.png"
                    class="nextIcon-top"
                     alt="Description of image"></th>
                <th><h4> Patient Panel</h4></th>
            </tr>
        </table>
        
        
        
    </div>
    <div class="grid-container">
        <div class="grid-item1">
            <ul class="list">
                <li class="centered">
                    <div class="circle">
                        <img src="Images/Patient Icon.png"
                             class="responsive-image" alt="Patient Icon">
                    </div>
                </li>
                <li><button class="button" onclick="showContainer('container1',this)">Dashboard</button></li>
                <li><button class="button" onclick="showContainer('container2',this)">My Profile</button></li>
                <li><button class="button" onclick="showContainer('container3',this)">Book Appointment</button></li>
                <li><button class="button" onclick="showContainer('container4',this)">Appointment History</button></li>
                <li><a href="patient.php"><button class="button" >Logout</button></a></li>
            </ul>
        </div>
        
        <div class="grid-item2">
            <div id="container1" class="container active">
                <h2>Welcome <?php echo htmlspecialchars($name); ?>..!</h2>
                <div class="box">
                             <table class="table">
                                <tr>
                                    <th><a onclick="showContainer('container3',this)">
                                        <div class="box-add"><img src="Images/Book a appoientment.png"
                                    class="responsive-image" alt="Patient Icon"></div></a>
                                        
                                    
                                        </th>
                                    <th><a onclick="showContainer('container4',this)">
                                        <div class="box-add"><img src="Images/Appointment history.png"
                                    class="responsive-image" alt="Patient Icon"></div></a>
                                        
                                        </th>
                                </tr>
                                <tr>
                                    <td>My Appointment</td>
                                    <td>Book A Appointment</td>
                                </tr>
                                <tr>
                                    <td><div class="font">My Appointment</div></td>
                                    <td><div class="font">Appointment History</div></td>
                                </tr>
                            </table></div>
                    
                </div>
        
        <div id="container2" class="container">
            <h2>Welcome <?php echo htmlspecialchars($name); ?>..!</h2>
                <div class="box">
                    <h3><u>Personal Details</u></h3>
                    <table class="table1">
                        <tr>
                            <td>Name</td>
                            <td>: <?php echo htmlspecialchars($name); ?></td>
                        </tr>
                        <tr>
                            <td>Email</td>
                            <td>:<?php echo htmlspecialchars($email); ?></td>
                        </tr>
                        <tr>
                            <td>NIC</td>
                            <td>:<?php echo htmlspecialchars($nic); ?></td>
                        </tr>
                        <tr>
                            <td>Age</td>
                            <td>:<?php echo htmlspecialchars($age); ?></td>
                        </tr>
                        <tr>
                            <td>Gender</td>
                            <td>:<?php echo htmlspecialchars($gender); ?></td>
                        </tr>
                    </table>
                            </div>
        </div>
        <div id="container3" class="container">
        <h2>Welcome <?php echo htmlspecialchars($name); ?>..!</h2>
            <div class="box">
                <h3><u>Create an appointment</u></h3>
                <div class="book-appointment">
                    <form action="book_appointment.php" method="post">
                        <table class="table1">
                            <tr>
                            <td><label for="fee">Patient</label></td>
                            <td><input name="name"  value="<?php echo htmlspecialchars($name); ?>">
                                </input></td>
                            </tr>
                            <tr>
                                <td><label for="doctors">Doctors</label></td>
                                <td><select id="doctors" name="doctor" required>
                                    <option value="">Choose a Doctor</option>
                                    <option value="doctor1">Doctor 1</option>
                                    <option value="doctor2">Doctor 2</option>
                                    <option value="doctor3">Doctor 3</option>
                                    <option value="doctor4">Doctor 4</option>
                                    <option value="doctor5">Doctor 5</option>
                                </select></td>
                            </tr>
                            <tr>
                                <td><label for="date">Date</label></td>
                                <td><input type="date" id="date" name="date" required></td>
                            </tr>
                            <tr>
                                <td><label for="time">Time</label></td>
                                <td><input type="time" id="time" name="time" required></td>
                            </tr>
                            <tr>
                                <td><label for="fee">Consuitancy Fee</label></td>
                                <td><label for="fee">2000/=</label></td>
                        </table>
                        <button class="submit-button" type="submit">Create new entry</button>
                        
                    </form>
                </div>
                
                        </div>
        </div>
        <div id="container4" class="container">
            <h2>Welcome <?php echo htmlspecialchars($name); ?>..!</h2>
                <div class="box">
                    <h3><u>Appointment History</u></h3>
                    <table class="appointment-history">
                        <tr>
                            <td><b>Doctor Name</b></td>
                            <td><b>Consultancy Fee</b></td>
                            <td><b>Appointment Date</b></td>
                            <td><b>Appointment Time</b></td>
                        </tr>
                    </table>
                    <hr>
                    <table class="appointment-history">
                        <?php  
                        foreach ($objects_array as $object) {
                            echo "<tr>";
                            echo "<td>" . $object->doctor_name. "</td>";
                            echo "<td>" . $object->fee."/=". "</td>";
                            echo "<td>" . $object->date. "</td>";
                            echo "<td>" . $object->time. "</td>";
                            echo "</tr>";
                        }
                          ?>
                    </table>
                            </div>
        </div>
       
    </div>
    </div>
    
    <script>
        var userEmail=localStorage.getItem('email');
        function showContainer(containerId, button) {
            var containers = document.querySelectorAll('.container');
            containers.forEach(function(container) {
                container.classList.remove('active');
            });
            var activeContainer = document.getElementById(containerId);
            activeContainer.classList.add('active');
            var buttons = document.querySelectorAll('.button');
            buttons.forEach(function(btn) {
                if (btn !== button) {
                    btn.classList.remove('clicked');
                }
            });
            button.classList.toggle('clicked');
        }
        document.addEventListener("DOMContentLoaded", function() {
            document.querySelector('.button').classList.add('clicked');
        });
    </script>
</body>
</html>
