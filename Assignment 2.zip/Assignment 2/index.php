<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <img src="images/Hospital.png" alt="Hospital Logo">
                <h1 style="font-size: 50px;">Kings Hospital &rarr;</h1>
                <h4 style="font-size: 30px;"> Admin panel</h4>
            </div>
            <div class="logout">
                <form action="logout.php" method="POST">
                    <button type="submit" id="logoutButton" style="color: aliceblue;">Logout</button>
                </form>
            </div>
        </header>
        <div class="content">
            <aside class="sidebar">
                <ul>
                    <li><a href="#" id="dashboardLink">Dashboard</a></li>
                    <li><a href="doctor_list.php" id="doctorListLink">Doctor List</a></li>
                    <li><a href="patient_list.php" id="patientListLink">Patient List</a></li>
                    <li><a href="appointment_details.php" id="appointmentDetailsLink">Appointment Details</a></li>
                    <li><a href="add_doctor.php">Add Doctor</a></li>
                    <li><a href="messages.php">Messages</a></li>
                </ul>
            </aside>
            <main>
                <div id="dashboardContent">
                    <h2>WELCOME ADMIN</h2>
                    <div class="cards">
                        <div class="card">
                            <img src="images/doctor.png" alt="Doctor List Icon">
                            <h3>Doctor List</h3>
                            <a href="doctor_list.php" id="viewDoctors">View Doctors</a>
                        </div>
                        <div class="card">
                            <img src="images/patient1.png" alt="Patient List Icon">
                            <h3>Patient List</h3>
                            <a href="patient_list.php" id="viewPatients">View Patients</a>
                        </div>
                        <div class="card">
                            <img src="images/appoinment_book.png" alt="Appointment Details Icon">
                            <h3>Appointment Details</h3>
                            <a href="appointment_details.php" id="viewAppointments">View Appointments</a>
                        </div>
                        <div class="card">
                            <img src="images/manage.png" alt="Manage Doctors Icon">
                            <h3>Manage Doctors</h3>
                            <a href="add_doctor.php">Add Doctors</a>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script src="scripts.js"></script>
</body>
</html>
