<?php
// Database connection details
$host = 'localhost';
$db = 'hospital';
$user = 'root'; // Replace with your database username
$pass = ''; // Replace with your database password

// Create a new PDO instance
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

// Check if the form has been submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['doctor-name'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm-password'];
    $email = $_POST['email'];
    $consultancyFees = $_POST['consultancy-fees'];

    // Basic validation
    if ($password !== $confirmPassword) {
        echo "Passwords do not match.";
        exit;
    }

    // Hash the password
    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    // Insert the new doctor into the database
    $query = 'INSERT INTO doctors (name, email, password, consultancy_fee) VALUES (:name, :email, :password, :consultancy_fee)';
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':name', $name);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $hashedPassword);
    $stmt->bindParam(':consultancy_fee', $consultancyFees);

    if ($stmt->execute()) {
        echo "Doctor added successfully.";
    } else {
        echo "Error adding doctor.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Doctor</title>
    <link rel="stylesheet" href="styles2.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <img src="images/Hospital.png" alt="Hospital Logo">
                <h1>Kings Hospital &rarr;</h1><h4> Admin panel</h4>
            </div>
            <div class="logout">
                <form action="logout.php" method="POST">
                    <button type="submit" id="logoutButton" style="color: aliceblue;">Logout</button>
                </form>
            </div>
        </header>
        <div class="content">
            <aside class="sidebar">
                <ul>
                    <li><a href="index.php" id="dashboardLink">Dashboard</a></li>
                    <li><a href="doctor_list.php" id="doctorListLink">Doctor List</a></li>
                    <li><a href="patient_list.php" id="patientListLink">Patient List</a></li>
                    <li><a href="appointment_details.php" id="appointmentDetailsLink">Appointment Details</a></li>
                    <li><a href="add_doctor.php" class="active">Add Doctor</a></li>
                    <li><a href="#">Messages</a></li>
                </ul>
            </aside>
            <main>
                <h2>WELCOME ADMIN</h2>
                <form class="add-doctor-form" action="add_doctor.php" method="POST">
                    <div class="form-group">
                        <label for="doctor-name">Doctor Name:</label>
                        <input type="text" id="doctor-name" name="doctor-name" required>
                    </div>
                    <div class="form-group">
                        <label for="password">Password:</label>
                        <input type="password" id="password" name="password" required>
                    </div>
                    <div class="form-group">
                        <label for="confirm-password">Confirm Password:</label>
                        <input type="password" id="confirm-password" name="confirm-password" required>
                    </div>
                    <div class="form-group">
                        <label for="email">Email ID:</label>
                        <input type="email" id="email" name="email" required>
                    </div>
                    <div class="form-group">
                        <label for="consultancy-fees">Consultancy Fees:</label>
                        <input type="number" id="consultancy-fees" name="consultancy-fees" required>
                    </div>
                    <button type="submit">Add Doctor</button>
                </form>
            </main>
        </div>
    </div>
    <script src="scripts.js"></script>
</body>
</html>
