<?php

$con = mysqli_connect("localhost", "root", "");


if (!$con) {
    die('Could not connect: ' . mysqli_connect_error());
}


mysqli_select_db($con, "hospital");


$sql = "CREATE TABLE IF NOT EXISTS Message_details (
    userID int NOT NULL AUTO_INCREMENT,
    fullName varchar(30),
    email varchar(30),
    phoneNumber varchar(15), 
    subject varchar(50),
    message varchar(500),
    PRIMARY KEY(userID)
);";

// Execute the table creation query
if (mysqli_query($con, $sql)) {
    echo "Table 'Message_details' created successfully<br>";
} else {
    echo "Error creating table: " . mysqli_error($con) . "<br>";
}

// Prepare and bind the INSERT statement to prevent SQL injection
$stmt = mysqli_prepare($con, "INSERT INTO Message_details (fullName,email,phoneNumber,subject,message) VALUES (?, ?, ?, ?, ?)");
mysqli_stmt_bind_param($stmt, "sssss", $fullName,$email,$phoneNumber,$subject,$message);

// Assign variables from the POST request
$fullName = $_POST['fullName'];
$email = $_POST['email'];
$phoneNumber = $_POST['phoneNumber'];
$subject = $_POST['subject'];
$message = $_POST['message'];

// Execute the prepared statement
if (mysqli_stmt_execute($stmt)) {
    echo "<script>alert('Sent your message'); window.location.href='Home.php';</script>";
} else {
    echo "Error: " . mysqli_stmt_error($stmt);
}

// Close the statement and connection
mysqli_stmt_close($stmt);
mysqli_close($con);
?>
