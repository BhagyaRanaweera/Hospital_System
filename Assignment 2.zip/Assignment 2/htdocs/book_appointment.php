<?php
// Check if form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // Database configuration
    $servername = "localhost"; // or your server name
    $username = "root"; // your database username
    $password = ""; // your database password
    $dbname = "Hospital"; // your database name

    // Create connection
    $conn = new mysqli($servername, $username, $password, $dbname);

    // Check connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $userName = $_POST['name'];
    $date = $_POST['date'];
    $time = $_POST['time'];
    $doctor =$_POST['doctor'];
    $fee = 2000;

    echo''. $date .''. $time .''. $doctor .''.$username.''.$fee.'';

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO appointment (patient_name, date, time, fee, doctor_name) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssis", $userName, $date,$time,$fee,$doctor);

    // Execute the query
    if ($stmt->execute()) {
        echo "<script>
        window.history.back();
        alert('Booked your appointment..!');
        </script>";
        
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();
}

?>