<?php

$host = 'localhost';
$db = 'hospital';
$user = 'root'; 
$pass = ''; 


try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

$query = 'SELECT name, email, contact, message FROM feedback';
$params = [];


if (isset($_POST['search']) && !empty($_POST['search'])) {
    $search = $_POST['search'];
    $query .= ' WHERE contact LIKE :search';
    $params[':search'] = "%$search%";
}

$stmt = $pdo->prepare($query);
$stmt->execute($params);
$feedbacks = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Messages</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <img src="images/Hospital.png" alt="Hospital Logo">
                <h1>Kings Hospital &rarr;</h1><h4> Admin panel</h4>
            </div>
            <div class="logout">
                <form action="logout.php" method="POST">
                    <button type="submit" id="logoutButton" style="color: aliceblue;">Logout</button>
                </form>
            </div>
        </header>
        <div class="content">
            <aside class="sidebar">
                <ul>
                    <li><a href="index.php" id="dashboardLink">Dashboard</a></li>
                    <li><a href="doctor_list.php" id="doctorListLink">Doctor List</a></li>
                    <li><a href="patient_list.php" id="patientListLink">Patient List</a></li>
                    <li><a href="appointment_details.php" id="appointmentDetailsLink">Appointment Details</a></li>
                    <li><a href="add_doctor.php" id="addDoctorLink">Add Doctor</a></li>
                    <li><a href="messages.php" class="active">Messages</a></li>
                </ul>
            </aside>
            <main>
                <h2>WELCOME ADMIN</h2>
                <div class="search-bar">
                    <form method="POST" action="messages.php">
                        <input type="text" name="search" placeholder="Enter Contact">
                        <button type="submit" id="searchButton">Search</button>
                    </form>
                </div>
                <table>
                    <thead>
                        <tr>
                            <th>User Name</th>
                            <th>Email</th>
                            <th>Contact</th>
                            <th>Message</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($feedbacks)): ?>
                            <?php foreach ($feedbacks as $feedback): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($feedback['name']); ?></td>
                                    <td><?php echo htmlspecialchars($feedback['email']); ?></td>
                                    <td><?php echo htmlspecialchars($feedback['contact']); ?></td>
                                    <td><?php echo htmlspecialchars($feedback['message']); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4">No feedbacks found.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </main>
        </div>
    </div>
    <script src="scripts.js"></script>
</body>
</html>
