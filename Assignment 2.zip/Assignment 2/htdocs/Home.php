<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Kings Hospital</title>
        <style>
            body{
                padding: 0px;
                margin: 0px;
                font-family: Arial, sans-serif;
                background:rgba(0,0,0,0.7)url("images/bg.jpeg");
                background-repeat: no-repeat;
                background-size:contain;
                background-blend-mode: darken;
            }
            .navbar{
                position: fixed;
                width: 100%;
                top: 0;
                margin-bottom: 0;
                
            }
            .navbar ul{
                list-style-type: none;
                
                padding: 0px;
                margin: 0px;
                overflow: hidden;
                
            }
            
            .navbar li{
                float: right;
            }
            .navbar a{
                color: hsl(0, 0%, 100%);
                text-decoration: none;
                display: block;
                width: 100px;
                padding: 15px;
            }
            .navbar a:hover{
                color: hsl(0, 1%, 69%);
            }
            .navbar img{
                width: 50px;
                height: 48px;
                float: left;
                /*background-color: hsl(173, 100%, 24%);*/
                padding: 0px;
                margin: 0px;
                
            }
            .navbar h5{
                float: left;
                
                width: 500px;
                height: 48px;
                padding: 0px;
                margin: 0px;
                color: white;
                font-size: 2em;
                padding-top: 6px;
            }
            nav.sticky{
                background-color: hsl(173, 100%, 24%);
            }
            .home_container{
                padding: 0;
                margin: 0;
                
                height: 100vh;
                
            }
            h1{
                text-align: center;
                font-size: 9em;
                margin-bottom:0px ;
                margin-top: 100px;
                color: white;
            }
            .caption{
                margin: 60px;
                text-align: center;
                color: white;
            }
            .login_container{
                
                background-color: #f0f8ff;
                overflow: hidden;
                padding: 2em;
                height: 100vh;
            }
            .login_container h2{
                font-size: 5em;
                color: rgb(11, 65, 11);
                
            }
            .patient_card{
                background-color: #fff;
                padding: 2em;
                border-radius: 10px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                text-align: center;
                display: inline-block;
                height: 50vh;
                width: 250px;
                margin-left: 100px;
            }
            .patient_card h4{
                font-size: 75px;
                margin: 10px;
                padding: 0px;
                font-family: 'Times New Roman', Times, serif;
                color: #276059;
            }
            .icon {
                width: 250px;
                height: 300px;
                margin: 0;
                padding: 0;
                margin-right: 100px;
            }
            .login_container a:hover span{
                box-shadow: 0 4px 8px rgba(0, 0, 0, 100);
            }
            .service_container{
                background-color: #E0F7FA;
                overflow: hidden;
                padding: 2em;
                height: 100vh;
            }
            .service1{
                background-color: #E0F7FA;
                padding: 1em;
                border-radius: 10px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0);
                text-align: center;
                display: inline-block;
                height: 30vh;
                width: 200px;
                margin-left: 100px;
                font-size: small;
            }
            .service1_icons{
                width: 100px;
                height: 100px;
                margin: 0px;
                padding: 0;
                margin-right: 800px;
                margin-left: 50px;
            }
            .service1 b{
                font-size: 2em;
            }
            .inter_service_container{
                margin-top: 100px;
            }
            .service2{
                background-color: #E0F7FA;
                padding: 2em;
                border-radius: 10px;
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
                text-align: center;
                display: inline-block;
                height: 15vh;
                width: 500px;
                margin-left: 100px;
                font-size: small;
                margin-right: 1px;
            }
            .service2_icons{
                width: 100px;
                height: 100px;
                margin: 0px;
                padding: 0;
                margin-right: 1000px;
                margin-left: 23px;
                float:left;
            }
            .service2 p{
                text-align: justify;
                margin-left: 140px;
                margin-top: 7px;
                position: absolute;
                width: 300px;
            }
            .service2 b{
                font-size: 2em;
            }
            .contact_container{
                background-color: #f0f8ff;
                overflow: hidden;
                padding: 2em;
                height: 85vh;
                text-align: center;
            }
            .contact_container_form{
                border: solid;
                border-radius: 10px;
                width: 50%;
                margin-left: 350px;
                padding: 0;
                border-color: #276059;
                border-width: 5px;
                background-color: hsl(120, 11%, 87%);
            }
            .contact_container input[type="text"]{
                width: 50%;
                border-radius: 5px;
                padding: 0;
                margin: 0;
                border-color: #276059;
                border-width: 3px;
                font-size: medium;
            }
            .contact_container input[type="submit"]{
                margin-bottom: 10px;
                width: 30%;
                border-radius: 40px;
                background-color: #276059;
                color: white;
                font-size: medium;
            }
            .contact_container textarea{
                border-color: #276059;
                border-width: 3px;
                border-radius: 5px;
            }
            .footer{
                height: 20vh;
                background-color: hsl(173, 100%, 24%);
            }
            .nav_links ul{
                list-style-type: none;
                padding: 0;
                margin: 0;
                padding-left: 150px;
                padding-top: 20px;
                display: block;
                width: 100px;
                float: left;
            }
            .nav_links li{
                padding-bottom: 5px;
            }
            .nav_links a{
                text-decoration: none;
                color: white;
            }
            .address{
                color: white;
                font-size: 15px;
                margin-left: 200px;
                padding-top: 12px;
                float: left;
            }
            .copy_rights{
                color: white;
                text-align: center;
                
            }
            .copy_rights p{
                margin: 0;
                padding: 0;
            }
            .footer hr{
                width: 80%;
            }
            .social_media p{
                color: white;
                font-size:30px; 
                padding: 0;
                margin: 0;
                padding-left: 900px;
                padding-top: 10px;
            }
            .facebook img{
                width: 50px;
                padding: 0;
                margin: 0;
                padding-left: 100px;
                padding-top: 20px;

            }
            .linkedin img{
                width: 50px;
                padding: 0;
                margin: 0;
                padding-left: 30px;
                padding-top: 20px;

            }
            .twitter img{
                width: 50px;
                padding: 0;
                margin: 0;
                padding-left: 30px;
                padding-top: 20px;
            }
            .youtube img{
                width: 50px;
                padding: 0;
                margin: 0;
                padding-left: 30px;
                padding-top: 20px;
            }
            .home_container .text{
                color: green;
            }
            
        </style>

        <script src="ValidateForm.js"></script>
    </head>
    <body>
        <nav class="navbar">
            <img src="images/Hospital.png">
            <h5>Kings Hospital</h5>
            <ul>
                <li><a href="#contact">CONTACT</a></li>
                <li><a href="#aboutus">ABOUT US</a></li>
                <li><a href="#login">LOG IN</a></li>
                <li><a href="#home">HOME</a></li>
            </ul>
        </nav>

        <main>
            <a name="home"><div class="home_container">
                <h1>Where <span class="text">compassion</span> meets <span class="text">care,</span> and <span class="text">healing</span> begins.</h1>
                <p class="caption"><i>"A health care center serves as a vital hub for community well-being, offering a wide range of medical services designed to meet the diverse needs of patients. Equipped with state-of-the-art technology and staffed by a team of dedicated professionals, these centers provide comprehensive care that includes preventive health services, diagnostic evaluations, and treatment for both acute and chronic conditions. Emphasizing a patient-centered approach, health care centers strive to create a welcoming environment where individuals receive personalized attention and compassionate care. By promoting health education and wellness programs, they play a crucial role in improving the overall health of the community, ensuring that quality medical care is accessible to all."</i></p>
            </div></a>
            <a name="login"><div class="login_container">
                <h2>LOG IN AS A...</h2>
                <a href="patient.php" target="_blank"><span class="patient_card">
                    <img src="images/patient.png" class="icon">
                    <h4>Patient</h4>
                </span></a>
                <a href="doctor_login.php" target="_blank"><span class="patient_card">
                    <img src="images/doctor.png" class="icon">
                    <h4>Doctor</h4>
                </span></a>
                <a href="admin.php" target="_blank"><span class="patient_card">
                    <img src="images/admin.png" class="icon">
                    <h4 style="color: hsl(0, 68%, 46%);">Admin</h4>
                </span></a>
            </div></a>
            <hr>
            <a name="aboutus"><div class="service_container">
                <span class="service1">
                    <img src="images/booking.png" class="service1_icons">
                    <p><b>Make an appointment</b><br>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem, labore. Id eos vitae quasi cum sed quis eum soluta nobis expedita, excepturi, repellendus cupiditate corporis, commodi mollitia voluptates illum magnam!</p>
                </span>
                <span class="service1">
                    <img src="images/check-list.png" class="service1_icons">
                    <p><b>Choose your package</b><br>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem, labore. Id eos vitae quasi cum sed quis eum soluta nobis expedita, excepturi, repellendus cupiditate corporis, commodi mollitia voluptates illum magnam!</p>
                </span>
                <span class="service1">
                    <img src="images/doctor1.png" class="service1_icons">
                    <p><b>Help by specialist</b><br>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem, labore. Id eos vitae quasi cum sed quis eum soluta nobis expedita, excepturi, repellendus cupiditate corporis, commodi mollitia voluptates illum magnam!</p>
                </span>
                <span class="service1">
                    <img src="images/application-form.png" class="service1_icons">
                    <p><b>Get diagnostic report</b><br>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem, labore. Id eos vitae quasi cum sed quis eum soluta nobis expedita, excepturi, repellendus cupiditate corporis, commodi mollitia voluptates illum magnam!</p>
                </span>
                <div class="inter_service_container">
                    <span class="service2">
                        <img src="images/medical-stethoscope-variant.png" class="service2_icons">
                        
                        <p><b>Medical Checkup</b><br>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem, labore. Id eos vitae quasi cum sed quis eum soluta nobis expedita, excepturi, repellendus cupiditate corporis, commodi mollitia voluptates illum magnam!</p>
                    </span>
                    <span class="service2">
                        <img src="images/handicap.png" class="service2_icons">
                        <p><b>Nursing Services</b><br>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem, labore. Id eos vitae quasi cum sed quis eum soluta nobis expedita, excepturi, repellendus cupiditate corporis, commodi mollitia voluptates illum magnam!</p>
                    </span>
                    <span class="service2">
                        <img src="images/online-pharmacy.png" class="service2_icons">
                        <p><b>Pharmacy</b><br>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem, labore. Id eos vitae quasi cum sed quis eum soluta nobis expedita, excepturi, repellendus cupiditate corporis, commodi mollitia voluptates illum magnam!</p>
                    </span>
                    <span class="service2">
                        <img src="images/brain.png" class="service2_icons">
                        <p><b>Neurology</b><br>Lorem ipsum dolor sit amet consectetur adipisicing elit. Autem, labore. Id eos vitae quasi cum sed quis eum soluta nobis expedita, excepturi, repellendus cupiditate corporis, commodi mollitia voluptates illum magnam!</p>
                    </span>
                </div>
            </div></a>
            <hr>
            <a name="contact"><div class="contact_container">
                <div class="contact_container_form">
                    <form name="from1" action="message.php" method="POST" enctype="application/x-www-form-urlencoded" onsubmit="return validateForm()">
                        <input type="text" name="fullName" placeholder="Full Name" style="margin-top: 20px;"><br><br><br>
                        <input type="text" name="email" placeholder="Email Address"><br><br><br>
                        <input type="text" name="phoneNumber" placeholder="Phone Number"><br><br><br>
                        <input type="text" name="subject" placeholder="Subject"><br><br><br>
                        <textarea rows="20" cols="67" name="message" placeholder="Message"></textarea><br><br><br>
                        <input type="submit" value="Send Message">
                    </form>
                </div></a>
            </div>
        </main>
        <footer>
            <div class="footer">
                <div class="nav_links">
                    <ul>
                        <li><a href="#home">HOME</a></li>
                        <li><a href="#login">LOG IN</a></li>
                        <li><a href="#aboutus">ABOUT US</a></li>
                        <li><a href="#contact">CONTACT</a></li>
                    </ul>
                </div>
                <div class="address">
                    <p>Address: No 12,Dam Street, Bambalapitiya, Colombo 12</p>
                    <p>Email: kingshospital@gmail.com</p>
                    <p>Phone Number: 033-1123454</p>
                </div>
                <div class="social_media">
                    <p>Follow us on:</p>
                    <span class="facebook">
                        <a href="www.facebook.com" target="_blank"><img src="images/facebook.png"></a>
                    </span>
                    <span class="linkedin">
                        <a href="www.linkedin.com" target="_blank"><img src="images/linkedin.png"></a>
                    </span>
                    <span class="twitter">
                        <a href="www.twitter.com" target="_blank"><img src="images/twitter.png"></a>
                    </span>
                    <span class="youtube">
                        <a href="www.youtube.com" target="_blank"><img src="images/youtube.png"></a>
                    </span>
                </div>
                <hr>
                <div class="copy_rights">
                    <p>&copy; 2024 Kings Hospital. All Rights Reserved.</p>
                </div>
            </div>

            <script type="text/javascript">
                window.addEventListener("scroll", function(){
                    var nav = document.querySelector("nav");
                    nav.classList.toggle("sticky", window.scrollY > 0);
                })
            </script>
        </footer>
    </body>
</html>