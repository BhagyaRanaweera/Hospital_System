<?php
// Database connection
$user = 'root';
$pass = '';
$dbName = 'hospital';

$conn = new mysqli('localhost', $user, $pass, $dbName);

// Check connection
if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Handle search query
$search = isset($_POST['search']) ? $_POST['search'] : '';

// Prepare SQL query
$sql = "SELECT name, password, email, consultancy_fee FROM doctor";
if ($search) {
    $search = $conn->real_escape_string($search);
    $sql .= " WHERE email LIKE '%$search%'";
}

// Execute SQL query
$result = $conn->query($sql);

// Fetch results
$doctors = [];
if ($result) {
    while ($row = $result->fetch_assoc()) {
        $doctors[] = $row;
    }
    $result->free();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Doctor List</title>
    <link rel="stylesheet" href="Styles.css">
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Highlight active link in the sidebar
            const sidebarLinks = document.querySelectorAll('.sidebar ul li a');
            sidebarLinks.forEach(link => {
                link.addEventListener('click', function() {
                    sidebarLinks.forEach(l => l.classList.remove('active'));
                    this.classList.add('active');
                });
            });

            // Confirmation before logging out
            const logoutButton = document.getElementById('logoutButton');
            logoutButton.addEventListener('click', function(event) {
                const confirmLogout = confirm('Are you sure you want to log out?');
                if (!confirmLogout) {
                    event.preventDefault();
                }
            });
        });
    </script>
</head>
<body>
    <div class="container">
        <header>
            <div class="logo">
                <img src="images/Hospital.png" alt="Hospital Logo">
                <h1>Kings Hospital &rarr;</h1><h4> Admin panel</h4>
            </div>
            <div class="logout">
                <form action="admin.php" method="POST">
                    <button type="submit" id="logoutButton" style="color: aliceblue;">Logout</button>
                </form>
            </div>
        </header>
        <div class="content">
            <aside class="sidebar">
                 <ul>
                    <li><a href="AdminLogin.php" id="dashboardLink">Dashboard</a></li>
                    <li><a href="doctor_list.php" id="doctorListLink">Doctor List</a></li>
                    <li><a href="patient_list.php" id="patientListLink">Patient List</a></li>
                    <li><a href="appoinment_details.php" id="appointmentDetailsLink">Appointment Details</a></li>
                    <li><a href="add_doctor.php" id="addDoctorLink">Add Doctor</a></li>
                    <li><a href="message.php" id="messagesLink">Messages</a></li>
                </ul>
            </aside>
            <main>
                <h2>Doctor List</h2>
                <form method="POST">
                    <input type="text" name="search" placeholder="Search by Email ID" value="<?php echo htmlspecialchars($search); ?>">
                    <button type="submit">Search</button>
                </form>
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Password</th>
                            <th>Email</th>
                            <th>Fee</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($doctors as $doctor): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($doctor['name']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['password']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['email']); ?></td>
                            <td><?php echo htmlspecialchars($doctor['consultancy_fee']); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </main>
        </div>
    </div>
</body>
</html>
